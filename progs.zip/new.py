sss = input("enter word:")
print("your word is:", sss)
print(type(sss))
a = list(sss)
print(a)
FLet, *middle, LLet = a
print(FLet, LLet, middle)
print(set(sss))