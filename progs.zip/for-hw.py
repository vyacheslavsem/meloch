for i in range(ord("a"),ord("z")+1):
    for j in range(ord("A"),ord("Z")+1):
        for k in range(ord("1"),ord("9")+1):
            for f in range(ord("1"),ord("9")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')

for i in range(ord("1"),ord("9")+1):
    for j in range(ord("a"),ord("z")+1):
        for k in range(ord("A"),ord("Z")+1):
            for f in range(ord("1"),ord("9")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')

for i in range(ord("1"),ord("9")+1):
    for j in range(ord("1"),ord("9")+1):
        for k in range(ord("a"),ord("z")+1):
            for f in range(ord("A"),ord("Z")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')

for i in range(ord("A"),ord("Z")+1):
    for j in range(ord("1"),ord("9")+1):
        for k in range(ord("1"),ord("9")+1):
            for f in range(ord("a"),ord("z")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')


for i in range(ord("A"),ord("Z")+1):
    for j in range(ord("a"),ord("z")+1):
        for k in range(ord("1"),ord("9")+1):
            for f in range(ord("1"),ord("9")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')

for i in range(ord("1"),ord("9")+1):
    for j in range(ord("A"),ord("Z")+1):
        for k in range(ord("a"),ord("z")+1):
            for f in range(ord("1"),ord("9")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')

for i in range(ord("1"),ord("9")+1):
    for j in range(ord("1"),ord("9")+1):
        for k in range(ord("A"),ord("Z")+1):
            for f in range(ord("a"),ord("z")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')

for i in range(ord("a"),ord("z")+1):
    for j in range(ord("1"),ord("9")+1):
        for k in range(ord("1"),ord("9")+1):
            for f in range(ord("A"),ord("Z")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')



for i in range(ord("1"),ord("9")+1):
    for j in range(ord("a"),ord("z")+1):
        for k in range(ord("1"),ord("9")+1):
            for f in range(ord("A"),ord("Z")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')

for i in range(ord("1"),ord("9")+1):
    for j in range(ord("A"),ord("Z")+1):
        for k in range(ord("1"),ord("9")+1):
            for f in range(ord("a"),ord("z")+1):
                print(chr(i),chr(j),chr(k),chr(f), sep='')