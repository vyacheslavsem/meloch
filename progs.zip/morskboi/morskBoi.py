def validate_coord(s):
    
    if len(s) > 3:
        return -1

    if (s[0] < 'a' and s[0] > 'z') or (s[0] < 'A' and s[0] > 'Z'):
        return -1

    if len(s) == 3:
        return i,j


class Ship:
    
    def __init__(self, n):
        с = validate_coord(input("Введите координату корабля: "))
        
        
