
import random
import re


# ВВЕДЕМ ИМЕНОВАННЫЕ КОНСТАНТЫ

RAND = True     # Использовать AI для имитации Игрока 1

# Размерность игры
RX = 11         # Горизонтальная размерность поля
RY = 11         # Вертикальная размерность поля

# Подписи для поля - легенда координат
# Легенда горизонтальных координат
RH = []
for i in range(RX):
    RH.append(chr(ord('A')+i))
# Легенда вертикальных координат
RV = []
for i in range(RY):
    RV.append(" "*(2-len(str(i+1)))+str(i+1))

# Легенды (обозначения) игрового поля
F_SHIP = "S"
F_RESTRICTED = "#"
F_RESTRICTED_EXPOSED = "%"
F_MISS = "*"
F_WOUND = "x"
F_KILL = "X"

# Обозначения при выводе игрового поля

# Симовлы рамки
CH = [""]*13

CH[0] = chr(9556)
CH[1] = chr(9552)
CH[2] = chr(9572)
CH[3] = chr(9559)

CH[4] = chr(9553)
CH[5] = chr(9474)

CH[6] = chr(9567)
CH[7] = chr(9472)
CH[8] = chr(9532)
CH[9] = chr(9570)

CH[10] = chr(9562)

CH[11] = chr(9575)
CH[12] = chr(9565)

# Объекты на поле
P_SHIP = chr(9608)*3
P_RESTRICTED = "###" 
P_MISS = " * "
P_WOUND = chr(9612)+"x"+chr(9616)
P_KILL = chr(9618)+"X"+chr(9618)

OBJ = [P_SHIP, P_WOUND, P_MISS, P_KILL, P_RESTRICTED]

# Флаги отображения
ALL = [F_SHIP, F_RESTRICTED, F_RESTRICTED_EXPOSED, F_MISS, F_WOUND, F_KILL]
ALIED = [F_SHIP, F_MISS, F_WOUND, F_KILL]
ENEMY = [F_RESTRICTED_EXPOSED, F_MISS, F_WOUND, F_KILL]

# Состав флота
FLEET = [4, 3, 3, 2, 2, 2, 1, 1, 1, 1]

# Стратегия игроков
# Глобальная переменная

strategy = {"A":[0,{}], "E":[0,{}]}

class Ship:
    
    def __init__(self, f, n):
        self.fleet = f  # Флот, в который входит корабль - он же игровое поле
        self.decks = n  # Количество палуб
        
        self.health = n         # Здоровье - количество целых палуб
        self.isSunk = False     # Потоплен или на плаву - На плаву

        res = -1 
        while res == -1:
            res = Ship.getPosition(self, RAND)
        
        self.coords = res
        
    def getPosition(self, r):
        decks = self.decks
        field = self.fleet
        
        rr = False
        if field.name == "A" and r == True:
            rr = True
        if field.name == "E":
            rr = True
        
        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        rr = True
        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        
        res = -1
        
        if rr == False:
            
            MSG = "Введите координаты вашего "+str(decks)+"-палубного корабля: "
            coord = -1
            while coord == -1:
                coord = validate_coord(input(MSG))
                if field.getFieldCoord(coord[0], coord[1], ALL) != "":
                    coord = -1
                    print("Здесь нельзя разместить корабль!")
                    continue
            
            MSG = "Введите направление размещения \t(U)p, (D)own, (L)eft, (R)ight: "
            direct = -1
            while direct == -1:
                direct = input(MSG)
                res = re.search(r"[UDLR]", direct.upper())
                if res == None:
                    direct = -1
                    continue
                direct = res[0]
                
        else:
            coord = -1
            while coord == -1:
                randcoord = str(RH[random.randint(0,RX-1)])+str(RV[random.randint(0, RY-1)])
                
                coord = validate_coord(randcoord)
                if coord == -1:
                    continue
            
                if field.getFieldCoord(coord[0], coord[1], ALL) != "":
                    coord = -1
                    #print("Здесь нельзя разместить корабль!")
                    continue
            
            direct = "UDLR"[random.randint(0,3)]
            
        di=[0]*4    # di = [0, 0, 0, 0]
        dj=[0]*4    # di = [0, 0, 0, 0]
        if direct == "U":
            di = [0, -1, -2, -3]
        if direct == "D":
            di = [0, 1, 2, 3]
        if direct == "L":
            dj = [0, -1, -2, -3]
        if direct == "R":
            dj = [0, 1, 2, 3]
                
        icoord = []
        jcoord = []
                
        for d in range(decks):
            icoord.append(coord[0]+di[d])
            jcoord.append(coord[1]+dj[d])
        
        # Проверяем, чтоб ни одна палуба не была за пределами поля
        # и не пыталась разместиться на занятой клетке
        for d in range(decks):
            i = icoord[d]
            j = jcoord[d]
            if Ship.isAtField(i, j) == False or Field.getFieldCoord(field, i, j, ALL) !="":
                if rr == False:
                    print("Здесь нельзя разместить корабль!")
                return -1
        # Проверки прошли - корабль может быть размещен по данным координатам
        # Печатаем рамку
        for d in range(decks):
           i = icoord[d]
           j = jcoord[d]
           
           Ship.putFrame(field, i, j, False)
        
        # Печатаем корабль поверх рамки
        for d in range(decks):
           i = icoord[d]
           j = jcoord[d]
           
           Field.putFieldCoord(field, i, j, F_SHIP)
        
        # Меняем результат функции с ошибки "-1" на координаты палуб
        res = (icoord, jcoord)
                
        return res
    
    def putFrame(f, i, j, exposed):
        field = f
        icoord = i
        jcoord = j
        
        if exposed == True:
            FLAG = F_RESTRICTED_EXPOSED
        else:
            FLAG = F_RESTRICTED
        
        di = [-1, 0, 1]
        dj = [-1, 0, 1]
        
        for i in range(3):
            for j in range(3):
                field_i = icoord+di[i]
                field_j = jcoord+dj[j]
                if Ship.isAtField(field_i, field_j) == True and\
                    field.getFieldCoord(field_i, field_j, ENEMY) !=F_MISS:
                    field.putFieldCoord(field_i, field_j, FLAG)
    
    def isAtField(i,j):
        res = False
        if (i >=0 and i < RY) and (j >= 0 and j < RX):
            res = True
        
        return res

class Field:
         
    def __init__(self,s):
        self.name = s
        self.__m = [""]*RX*RY
    
    def __str__(self):
        s=""
        for j in range(RX):
            for i in range(RY):
                s += format(self.__m[RX*i+j],"1")
                s+="."
            s += "\n"
            
        return s
    
    def getFieldCoord(self,i,j,F):
        v = self.__m[RX*i+j]
        if v in F:
            return v
        else: 
            return ""
    
    def putFieldCoord(self,i,j,v):
        self.__m[RX*i+j] = v


def validate_coord(s):
    ul=["",""]
    
    ul[0]=RH[-1].lower()
    ul[1]=RH[-1].upper()
    res = re.search(r"[a-"+ul[0]+r"A-"+ul[1]+r"]\s*\d{1,2}", s) 
    
    if res == None:
        return -1
    
    c = res[0]
        
    c[0].upper()
    j = RH.index(c[0].upper())
    
    
    n = re.findall(r"\d+",c)
    i = int(n[0])-1
    if i > RY-1:
        return -1
        
    return i,j

def print_all(a,e):
    f1 = ALIED
    f2 = ENEMY
    
    # Печать строки s0 - горизонтальные координаты
    s0 = " "
    for n in [1,2]:
        s0 += " "*4
        for i in RH:
            s0 += " "+i+" "*2
    print(s0)
    
    # Печать строки s1 - верх рамки
    s1 = " "
    for n in [1,2]:
        s1 += " "*3
        s1 += CH[0]
        for i in range(RX-1):
            s1 += CH[1]*3+CH[2]
        s1 += CH[1]*3+CH[3]
    print(s1) 
    
    # Печать строк 1-9
    for i in range(RY-1):
        
        # Печать строки s2 - данные с поля
        s2 = " "
                    
        s2 += RV[i]
        s2 += " "+CH[4]
        for j in range(RX-1):
            s2 += print_Coord(a, i, j, f1)
            s2 += CH[5]
        s2 += print_Coord(a, i, RX-1, f1)
        s2 += CH[4]
        
        s2 += RV[i]
        s2 += " "+CH[4]
        for j in range(RX-1):
            s2 += print_Coord(e, i, j, f2)
            s2 += CH[5]
        s2 += print_Coord(e, i, RX-1, f2)
        s2 += CH[4]
            
        print(s2)
        
        # Печать строки s3 - внутренняя перемычка
        s3 = " "
        for n in [1,2]:
            s3 += " "*3
            s3 += CH[6]
            for i in range(RX-1):
                s3 += CH[7]*3+CH[8]
            s3 += CH[7]*3+CH[9]
        print(s3) 
    
    # Печать строки s2 - данные с поля для последней строки
    i = RY-1
    s2 = " "
            
    s2 += RV[i]
    s2 += " "+CH[4]
    for j in range(RX-1):
        s2 += print_Coord(a, i, j, f1)
        s2 += CH[5]
    s2 += print_Coord(a, i, RX-1, f1)
    s2 += CH[4]
    
    s2 += RV[i]
    s2 += " "+CH[4]
    for j in range(RX-1):
        s2 += print_Coord(e, i, j, f2)
        s2 += CH[5]
    s2 += print_Coord(e, i, RX-1, f2)
    s2 += CH[4]
        
    print(s2)
    
    
    # Печать строки s4 - нижняя рамка
    s4 = " "
    for n in [1,2]:
        s4 += " "*3
        s4 += CH[10]
        for i in range(RX-1):
            s4 += CH[1]*3+CH[11]
        s4 += CH[1]*3+CH[12]
    print(s4) 
    
    
    

def print_Coord(f,i,j,F):
    # Функция считывает данные игрового поля и возвращает 
    # объект для печати
    
    # С читать объект игрового поля (Alied  или Enemy)
    # с учётом флагов видимости (ALL, ALIED, ENEMY)
    m = f.getFieldCoord(i,j,F)
    
    # Распознать объект и вернуть объект печати
    if m == "":
        return " "*3
    if m == F_SHIP:
        return P_SHIP
    if m == F_WOUND:
        return P_WOUND
    if m == F_KILL:
        return P_KILL
    if m == F_MISS:
        return P_MISS
    if m == F_RESTRICTED:
        return P_RESTRICTED
    if m == F_RESTRICTED_EXPOSED:
        return P_RESTRICTED
    
def make_move(f, s):
    # Объявляем переменную как глобальную
    global strategy
    
    # Определяем, на каком поле будет удар
    field = f
    fleet = s
    
    # Проверяем, хочет ли человек играть сам, или доверит AI
    rr = False
    if field.name == "E" and RAND == True:
        rr = True
    if field.name == "A":
        rr = True
          
    # Введем координаты удара
    # Если пользователь играет сам:
    if rr == False:
        MSG = "Введите координаты для удара: "
        
        res = -1
        while res == -1:
            res = validate_coord(input(MSG))
    # Если пользователь доверил AI или ход AI
    else:
        
        # Генерируем коодинаты для нанесения удара
        res = -1
        while res == -1:
            # Если в стратегии нет элементов
            # то есть, ранее не было попадания
            #удар наносится совершенно случайно
            if len(strategy[field.name][1]) == 0:
                # Генерируем случайные координаты
                randcoord = str(RH[random.randint(0,RX-1)])+str(RV[random.randint(0, RY-1)])
                
                # Проверяем, что координаты игровые
                res = validate_coord(randcoord)
                if res == -1:
                    continue
                # Проверяем, что на поле по координатам нанесения удара ничего нет
                if field.getFieldCoord(res[0], res[1], ENEMY) != "":
                    # Если что-то есть - нужны другие координаты
                    res = -1
            
            # Ранее было попадание, значит нужно добить
            else:
                # В каком направлении будем бить
                curr_strategy = strategy[field.name][0]
                
                # Прочитали в стратегии координаты следующего удара
                i = strategy[field.name][1][curr_strategy][0][0]
                j = strategy[field.name][1][curr_strategy][0][1]
                
                # Проверили, находятся ли эти координаты на игровом поле
                if Ship.isAtField(i, j) == False:
                    # Если не на поле, нужны другие координаты из стратегии
                    res = -1
                    # Нужно сменить стратегию - направление удара
                    change_strat(field)
                    # Прервать итерацию цикла
                    continue
                
                # Переводим координаты стратегии (i,j) в A1-J10
                randcoord=str(RH[j])+str(RV[i])
                
                # Проверяем, что координаты игровые
                res = validate_coord(randcoord)
                if res == -1:
                    continue
                # Проверяем, что на поле по координатам нанесения удара ничего нет
                if field.getFieldCoord(res[0], res[1], ENEMY) != "":
                    # Если что-то есть - нужны другие координаты
                    res = -1
                    # Нужна другая стратегия
                    change_strat(field)
    
    # Зафиксируем координаты удара
    i = res[0]
    j = res[1]
    
    move_coords = ": "+str(RH[j])+str(RV[i]).lstrip(" ")
    print(move_coords)
    
    # Проверим результат удара
    if field.getFieldCoord(i, j, ALL) != F_SHIP:
        res = "MISS"
        field.putFieldCoord(i, j, F_MISS)
        
        if len(strategy[field.name][1]) != 0 and rr == True:
            change_strat(field)

    else:
        res = "WOUND"
        field.putFieldCoord(i, j, F_WOUND)
        
        if rr == True:
            if len(strategy[field.name][1]) == 0:
                # Создаем новую стратегию
                # Выбор случайного направления для следующих ударов
                curr_strategy = "UDLR"[random.randint(0,3)]
            
                # Описываем стратегию
                strategy[field.name] = [ # strategy["A"] / strategy["E"]
                                    # Текущее направление ударов
                                        curr_strategy,
                                        {
                                            # Стратегия ударов вверх
                                            "U": [[i-1,j],[i-2,j],[i-3,j]],
                                            # Стратегия ударов вниз
                                            "D": [[i+1,j],[i+2,j],[i+3,j]],
                                            # Стратегия ударов влево
                                            "L": [[i,j-1],[i,j-2],[i,j-3]],
                                            # Стратегия ударов вправо
                                            "R": [[i,j+1],[i,j+2],[i,j+3]]
                                        }
                                       ]
            else:
                # Второе попадание в корабль
                
                # Текущее направление удара
                curr_strategy = strategy[field.name][0]
                
                # Удалили из списка координат текущие,
                # по которым было попадание
                # чтобы не бить сюда в следующий раз
                del strategy[field.name][1][curr_strategy][0]
               
                # Определили, какие направления ударов еще есть в стратегии
                options = list(strategy[field.name][1].keys())
                
                # Если текущая результативная стратегия вертикальная
                # (2 попадания по вертикали)
                if curr_strategy == "U" or curr_strategy == "D":
                    
                    # можно убрать горизантальные направления,
                    # если они еще есть                                
                    if ("L" in options) == True:
                        del strategy[field.name][1]["L"]
                    
                    if ("R" in options) == True:
                        del strategy[field.name][1]["R"]
                
                # Если текущая результативная стратегия горизонтальная
                # (2 попадания по горизонтали)
                if curr_strategy == "R" or curr_strategy == "L":
                    
                    # можно убрать вертикальные направления,
                    # если они еще есть                
                    if ("U" in options) == True:
                        del strategy[field.name][1]["U"]
                    
                    if ("D" in options) == True:
                        del strategy[field.name][1]["D"]
                
        
        for ship in fleet:
            
            if i in ship.coords[0] and j in ship.coords[1]:
                ship.health -= 1
                
                if ship.health == 0:
                    ship.isSunk = True
                    res = "KILL"
                    
                    icoord = ship.coords[0]
                    jcoord = ship.coords[1]
                    
                    for d in range(ship.decks):
                        i = icoord[d]
                        j = jcoord[d]
                        Ship.putFrame(field, i, j, True)
                    
                    for d in range(ship.decks):
                        i = icoord[d]
                        j = jcoord[d]
                        field.putFieldCoord(i, j, F_KILL)
                    
                    fleet.remove(ship)
                    
                    if rr == True:
                        strategy[field.name][1]={}
                
    return res

def change_strat(field):
    # Эта функция меняет стратегию на новую, допустимую
    # Стратегиядобивания - направление нанесения удара UDLR
    
    # объявляем переменную глобальной
    global strategy
    
    # Прочитали текущую стратегию
    curr_strategy = strategy[field.name][0]
    
    # Удалили координаты по текущей стратегии
    del strategy[field.name][1][curr_strategy]
    
    # Прочитали набор оставшихся направлений нанесения удара
    options = list(strategy[field.name][1].keys())
    
    # Выбрали случайное направление удара
    curr_strategy = options[random.randint(0, len(options)-1)]
    
    # Внесли это направление в стратегию как текущую стратегию
    strategy[field.name][0] = curr_strategy
    
    
def main():
    
    Alied = Field("A")
    Enemy = Field("E")
    
       
    print_all(Alied, Enemy)
     
    AFleet = []
    for decks in FLEET:
            AFleet.append(Ship(Alied,decks))
            print_all(Alied, Enemy)
    
    EFleet = []
    for decks in FLEET:
            EFleet.append(Ship(Enemy,decks))
         
    print_all(Alied, Enemy)
    
    # Текущий игрок - человек (A - Alied)
    curr_player = "A"
    # Текущее поля для хода - вражеское (Enemy)
    curr_field = Enemy
    # Текущий флот для удара - вражеский (Enemy)
    curr_fleet = EFleet
    
    nmove = 1
    win = False
    while win != True:
        print(nmove,"ход: Игрок", curr_player, end="")
        
        print(strategy)
        
        res = make_move(curr_field, curr_fleet)
        
        print_all(Alied, Enemy)
        
        print(res,'\n')
        
        if res == 'MISS':
            if curr_player == "A": 
                curr_player = "E"
                curr_field = Alied
                curr_fleet = AFleet
            else: 
                curr_player = "A"
                curr_field = Enemy
                curr_fleet = EFleet
        
        if len(curr_fleet) == 0:
            win = True
        
        nmove += 1
        
    print(curr_player, "победил!")
    
    
main()

# \d    - любая цифра
# \d+   - Любая последовательность цифр (1 и более)
# \d*   - Любая последовательность цифр (0 и более)
# .     - Любой знак
# \w    - Любая буква, цифра или "_"
# \w+   - Любая последовательность букв, цифр или "_" (1 и более)
# \w*   - Любая последовательность букв, цифр или "_" (0 и более)
# \d{3} - Последовательность строго из 3 цифр 
# \d{1,3} - Последовательность из от 1 до 3 цифр
# [a-jA-J] - Любой символ из []