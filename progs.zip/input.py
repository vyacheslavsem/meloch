a = int
b = int
a = int(input("enter  1st number: "))
b = int(input("enter  2nd number: "))
print(type(a),type(b))
print("a + b = ", a+b)
print("a - b = ", a-b)
print("a x b = ", a*b)
print("a / b = ", a/b)
print("a ^ b = ", a**b)
print(2/3)
