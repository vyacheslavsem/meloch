string = "python"
print(string*4)
print("="*40)
print("длина строки string ", len(string))

