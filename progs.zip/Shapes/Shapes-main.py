import classShapes as s

def main():
    
    shape1 = s.Shapes(4, 2)   # 4 вершины, 1 длина стороны - это квадрат
    shape2 = s.Shapes(4, [2,4]) # 4 вершины, 2 длины - прямоугольник
    shape3 = s.Shapes(0,2*s.pi()*3) # Окружность
    
      
    print(shape1)
    print(shape2)
    print(shape3)
    print(shape3.findS())
    print()
    
    print(shape1,"\n")
    print("Первая фигура имеет", shape1.getVert(),"вершин(ы)")
    print("А длина сторон у неё равна", shape1.getLen())
    print("Поменяем длину сторон")
    shape1.setLen([5,6])
    print("Теперь первая фигура имеет", shape1.getVert(),"вершин(ы)")
    print("А длина сторон у неё равна", shape1.getLen())
    print("\n",shape1)
    print()
    
    shape3.setVert(-2)
    print(shape3)
    print()
    
    circle = s.Circle(0, 3, "Окружность")
    print(circle)
    print("Площадь круга", circle.findS())
    print("Длина окружности", circle.findP())
    print()
    
    rect = s.Rectangle(4,[5,6],"Прямоугольник")
    print(rect)
    print(rect.getLen())
    print("1-я сторона", rect.getLen()[0])
    print("2-я сторона", rect.getLen()[1])
    print("Площадь прямоугольника", rect.findS())
    print("Периметр прямоугольника", rect.findP())
    print()
    
    square = s.Square(4,3,"Квадрат")
    print(square)
    print("Площадь квадрата", square.findS())
    print("Периметр квадрата", square.findP())
    print()
    
    tri = s.Triangle(3,[5,3,4],"Треугольник")
    print(tri)
    print("Площадь треугольника", tri.findS())
    print("Периметр треугольника", tri.findP())
    print()
    
    print(s.pi())
    
    shape4 = s.Triangle(3,[5,5,5],"Равносторонний треугольник")
    print(shape4.getName(),shape4.findP(), shape4.findS())
    print()
    
    shape5 = s.Rectangle(4,[6,3,4,7], "Неравнобокая трапеция")
    print(shape5)
    print(shape5.getName(),shape5.findP(), shape5.findS())
    
main()