def pi():
    return 3.141592

class Shapes:
    
    def __init__(self, v, l):
        self.__vertices = v # Количество вершин
        self.__lenth = l # Длина сторон
    
    def __str__(self):
        return "У этой фигуры "+str(self.__vertices)+\
            " вершин. Стороны равны: "+str(self.__lenth)
    
    def setVert(self, v):
        if v < 0:
            print("Количество вершин не может быть отрицательным")
        else:
            self.__vertices = v
    
    def setLen(self, l):
        self.__lenth = l
    
    def getVert(self):
        return self.__vertices
    
    def getLen(self):
        return self.__lenth
    
    def findP(self):
        return "Необходимо уточнить форму фигуры"
    
    def findS(self):
        return "Необходимо уточнить форму фигуры"

class Circle(Shapes):
    
    def __init__(self, v, l, n):
        Shapes.__init__(self, v, l)
        self.__name = n
    
    def getName(self):
        return self.__name
    
    def __str__(self):
        return "Это окружность с радусом "+str(Shapes.getLen(self))
    
    def findP(self):
        r = Shapes.getLen(self)
        P = 2*pi()*r
        return P
    
    def findS(self):
        r = Shapes.getLen(self)
        S = pi()*r**2
        return S

class Square(Shapes):
    
    def __init__(self, v, l, n):
        Shapes.__init__(self, v, l)
        self.__name = n
    
    def getName(self):
        return self.__name
    
    def __str__(self):
        return "Это квадрат со стороной "+str(Shapes.getLen(self))
    
    def findP(self):
        a = Shapes.getLen(self)
        P = 4*a
        return P
    
    def findS(self):
        a = Shapes.getLen(self)
        S = a**2
        return S
    
class Rectangle(Shapes):
    
    def __init__(self, v, l, n):
        Shapes.__init__(self, v, l)
        if len(l) > 2:
            print("Неверное число сторон!")
            Shapes.setLen(self,"!!!")
        self.__name = n
    
    def getName(self):
        return self.__name
    
    def __str__(self):
        return "Это прямоугольник со сторонами "+str(Shapes.getLen(self))
    
    def findP(self):
        if Shapes.getLen(self) == "!!!":
            return "ОШИБКА!!!"
        a = Shapes.getLen(self)[0]
        b = Shapes.getLen(self)[1]
        P = 2*(a+b)
        return P
    
    def findS(self):
        if Shapes.getLen(self) == "!!!":
            return "ОШИБКА!!!"
        a = Shapes.getLen(self)[0]
        b = Shapes.getLen(self)[1]
        S = a*b
        return S

class Triangle(Shapes):
    
    def __init__(self, v, l, n):
        Shapes.__init__(self, v, l)
        self.__name = n
    
    def getName(self):
        return self.__name
    
    def __str__(self):
        return "Это треугольник со сторонами "+str(Shapes.getLen(self))
    
    def findP(self):
        a = Shapes.getLen(self)[0]
        b = Shapes.getLen(self)[1]
        c = Shapes.getLen(self)[2]
        P = a+b+c
        return P
    
    def findS(self):
        a = Shapes.getLen(self)[0]
        b = Shapes.getLen(self)[1]
        c = Shapes.getLen(self)[2]
        
        p = (a+b+c)/2
        
        S = (p*(p-a)*(p-b)*(p-c))**(1/2)
        return S